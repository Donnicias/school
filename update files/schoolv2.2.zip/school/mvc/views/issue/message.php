
<div class="col-sm-12">
    <?php echo "<h2>".  $this->lang->line("issue_message") ."</h2>"; ?>
</div>
