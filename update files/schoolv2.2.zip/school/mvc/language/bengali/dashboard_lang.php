<?php

$lang['panel_title'] = "ড্যাশবোর্ড";
$lang['dashboard_notice'] = "নোটিশ";
$lang['dashboard_username'] = "ইউজারনেম";
$lang['dashboard_email'] = "ইমেল";
$lang['dashboard_phone'] = "ফোন";
$lang['dashboard_address'] = "ঠিকানা";
$lang['dashboard_libraryfee'] = "লাইব্রেরী ফি";
$lang['dashboard_transportfee'] = "পরিবহন ফি";
$lang['dashboard_hostelfee'] = "হোস্টেল ফি";
$lang['dashboard_earning_graph'] = "আরনিং গ্রাফ";
$lang['dashboard_notpaid'] = "পরিশোধ হয়নি";
$lang['dashboard_partially_paid'] = "আংশিকভাবে পরিশোধ";
$lang['dashboard_fully_paid'] = "সম্পূর্ণ পরিশোধ";
$lang['dashboard_cash'] = "নগদ";
$lang['dashboard_cheque'] = "চেক";
$lang['dashboard_paypal'] = "পেপ্যাল";
$lang['dashboard_stripe'] = "স্ট্রাইপ";
$lang['dashboard_sample'] = "নমুনা";
$lang['view'] = "দৃশ্য";
