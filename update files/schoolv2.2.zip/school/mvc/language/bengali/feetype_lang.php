<?php

$lang['panel_title'] = "ফি প্রকার";
$lang['add_title'] = "একটি ফি টাইপ যোগ করুন";
$lang['slno'] = "#";
$lang['feetype_name'] = "ফি প্রকার";
$lang['feetype_note'] = "বিঃদ্রঃ";
$lang['action'] = "কর্ম";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_feetype'] = "ফি টাইপ যোগ করুন";
$lang['update_feetype'] = "আপডেট ফি প্রকার";
