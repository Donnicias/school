<?php

$lang['panel_title'] = "ব্যয়";
$lang['add_title'] = "একটি ব্যয় যোগ করুন";
$lang['slno'] = "#";
$lang['expense_expense'] = "নাম";
$lang['expense_date'] = "তারিখ";
$lang['expense_amount'] = "পরিমাণ";
$lang['expense_note'] = "বিঃদ্রঃ";
$lang['expense_uname'] = "ইউজার";
$lang['expense_total'] = "মোট";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_expense'] = "ব্যয় যোগ করুন";
$lang['update_expense'] = "আপডেট ব্যয়";
