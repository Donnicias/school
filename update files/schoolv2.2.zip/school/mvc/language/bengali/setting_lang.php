<?php

$lang['panel_title'] = "সেটিং";
$lang['add_title'] = "সেটিং পরিবর্তন";
$lang['setting_school_name'] = "সাইট শিরোনাম";
$lang['setting_school_phone'] = "ফোন নম্বর";
$lang['setting_school_email'] = "সিস্টেম ইমেল";
$lang['setting_school_address'] = "ঠিকানা";
$lang['setting_school_currency_code'] = "মুদ্রা কোড";
$lang['setting_school_currency_symbol'] = "মুদ্রা প্রতীক";
$lang['setting_school_automation'] = "অটোমেশন";
$lang['setting_school_footer'] = "ফুটার";
$lang['setting_school_photo'] = "লোগো";
$lang['update_setting'] = "আপডেট সেটিং";
$lang['upload_setting'] = "আপলোড";
$lang['settings_pde'] = "আপনার ক্রয় কোড সঠিক নয়.";
