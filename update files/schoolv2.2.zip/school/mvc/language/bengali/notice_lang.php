<?php

$lang['panel_title'] = "নোটিশ";
$lang['add_title'] = "একটি নোটিশ যোগ করুন";
$lang['slno'] = "#";
$lang['notice_title'] = "শিরোনাম";
$lang['notice_notice'] = "নোটিশ";
$lang['notice_date'] = "তারিখ";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['print'] = "প্রিন্ট";
$lang['pdf_preview'] = "পিডিএফ প্রদর্শন";
$lang["mail"] = "ইমেইল পিডিএফ পাঠান";
$lang['add_class'] = "নোটিশ যোগ করুন";
$lang['update_class'] = "আপডেট নোটিশ";
$lang['to'] = "থেকে";
$lang['subject'] = "বিষয়";
$lang['message'] = "মেসেজ";
$lang['send'] = "পাঠান";
$lang['mail_to'] = "টু ফিল্ডের প্রয়োজন.";
$lang['mail_valid'] = "টু ফিল্ডে ইমেইলটি সঠিক হতে হবে.";
$lang['mail_subject'] = "বিষয় ফিল্ডের প্রয়োজন.";
$lang['mail_success'] = "ইমেলটি সফলভাবে পাঠানো হয়েছে!";
$lang['mail_error'] = "উফ! ইমেলটি পাঠানো হয়নি!";
