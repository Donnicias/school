<?php

$lang['panel_title'] = "পরীক্ষার সময়সূচি";
$lang['add_title'] = "একটি পরীক্ষার সময়সূচি যোগ";
$lang['slno'] = "#";
$lang['examschedule_name'] = "পরীক্ষার নাম";
$lang['examschedule_classes'] = "ক্লাস";
$lang['examschedule_all_examschedule'] = "সমস্ত পরীক্ষার সময়সূচি";
$lang['examschedule_select_exam'] = "নির্বাচন পরীক্ষা";
$lang['examschedule_select_classes'] = "নির্বাচন ক্লাস";
$lang['examschedule_select_subject'] = "নির্বাচন বিষয়";
$lang['examschedule_select_section'] = "নির্বাচন শাখা";
$lang['examschedule_select_student'] = "নির্বাচন ছাত্রছাত্রী";
$lang['examschedule_section'] = "শাখা";
$lang['examschedule_student'] = "ছাত্রছাত্রী";
$lang['examschedule_subject'] = "বিষয়";
$lang['examschedule_date'] = "তারিখ";
$lang['examschedule_time'] = "সময়";
$lang['examschedule_examfrom'] = "শুরুর সময়";
$lang['examschedule_examto'] = "শেষের সময়";
$lang['examschedule_room'] = "রুম";
$lang['examschedule_note'] = "বিঃদ্রঃ";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_examschedule'] = "পরীক্ষার সময়সূচী যোগ করুন";
$lang['update_examschedule'] = "আপডেট পরীক্ষার সময়সূচি";
