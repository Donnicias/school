<?php

$lang['panel_title'] = "পরিবহন";
$lang['add_title'] = "একটি পরিবহন যোগ করুন";
$lang['slno'] = "#";
$lang['transport_route'] = "রুট নাম";
$lang['transport_vehicle'] = "গাড়ির নম্বর";
$lang['transport_fare'] = "রুট ভাড়া";
$lang['transport_note'] = "বিঃদ্রঃ";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_transport'] = "পরিবহন যোগ করুন";
$lang['update_transport'] = "আপডেট পরিবহন";
