<?php

$lang['panel_title'] = "পরীক্ষা";
$lang['add_title'] = "একটি পরীক্ষার যোগ করুন";
$lang['slno'] = "#";
$lang['exam_name'] = "পরীক্ষার নাম";
$lang['exam_date'] = "তারিখ";
$lang['exam_note'] = "নোট";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_exam'] = "পরীক্ষা যোগ করুন";
$lang['update_exam'] = "আপডেট পরীক্ষা";
