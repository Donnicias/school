<?php

$lang['panel_title'] = "ক্লাস";
$lang['add_title'] = "একটি ক্লাস যুক্ত করুন";
$lang['slno'] = "#";
$lang['classes_name'] = "ক্লাস";
$lang['classes_numeric'] = "ক্লাস সংখ্যাসূচক";
$lang['teacher_name'] = "শিক্ষকের নাম";
$lang['classes_note'] = "নোট";
$lang['action'] = "কর্ম";
$lang['classes_select_teacher'] = "নির্বাচন শিক্ষক";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_class'] = "ক্লাস যুক্ত করুন";
$lang['update_class'] = "আপডেট ক্লাস";
