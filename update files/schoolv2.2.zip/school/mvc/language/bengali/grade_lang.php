<?php

$lang['panel_title'] = "গ্রেড";
$lang['add_title'] = "একটি গ্রেড যোগ করুন";
$lang['slno'] = "#";
$lang['grade_name'] = "গ্রেড নাম";
$lang['grade_point'] = "গ্রেড পয়েন্ট";
$lang['grade_gradefrom'] = "মার্ক শুরু";
$lang['grade_gradeupto'] = "মার্ক শেষ";
$lang['grade_note'] = "বিঃদ্রঃ";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_class'] = "গ্রেড যোগ করুন";
$lang['update_class'] = "আপডেট গ্রেড";
