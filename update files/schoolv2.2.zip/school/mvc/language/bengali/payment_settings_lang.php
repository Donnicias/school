<?php

$lang['panel_title'] = "পেমেন্ট সেটিংস";
$lang['paypal_email'] = "পেপ্যাল ইমেইল";
$lang['paypal_api_username'] = "পেপ্যাল ​​এপিআই ইউজারনেম";
$lang['paypal_api_password'] = "পেপ্যাল ​​এপিআই পাসওয়ার্ড";
$lang['paypal_api_signature'] = "পেপ্যাল ​​এপিআই স্বাক্ষর";
$lang['paypal_demo'] = "পেপ্যাল ​​স্যান্ডবক্স";
$lang['save'] = "সংরক্ষণ";
$lang['tab_paypal'] = "পেপ্যাল";
$lang['tab_stripe'] = "স্ট্রাইপ";
$lang['stripe_private_key'] = "স্ট্রাইপ প্রাইভেট কী";
$lang['stripe_public_key'] = "স্ট্রাইপ পাবলিক কী";
