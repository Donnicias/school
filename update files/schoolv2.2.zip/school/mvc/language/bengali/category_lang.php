<?php

$lang['panel_title'] = "বিভাগ";
$lang['add_title'] = "একটি বিভাগ যোগ করুন";
$lang['slno'] = "#";
$lang['category_hname'] = "হোস্টেল নাম";
$lang['category_class_type'] = "ক্লাস প্রকার";
$lang['category_hbalance'] = "হোস্টেল ফি";
$lang['category_note'] = "বিঃদ্রঃ";
$lang['category_select_hostel'] = "নির্বাচন হোস্টেল";
$lang['action'] = "কর্ম";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_category'] = "বিভাগ যোগ করুন";
$lang['update_category'] = "আপডেট বিভাগ";
