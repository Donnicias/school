<?php

$lang['panel_title'] = "পরীক্ষার উপস্থিতি";
$lang['add_title'] = "পরীক্ষার উপস্থিতি যোগ করুন";
$lang['slno'] = "#";
$lang['eattendance_photo'] = "ছবি";
$lang['eattendance_name'] = "নাম";
$lang['eattendance_email'] = "এটি ইমেল";
$lang['eattendance_roll'] = "রোল";
$lang['eattendance_phone'] = "ফোন";
$lang['eattendance_attendance'] = "উপস্থিতি";
$lang['eattendance_section'] = "শাখা";
$lang['eattendance_exam'] = "পরীক্ষা";
$lang['eattendance_classes'] = "ক্লাস";
$lang['eattendance_subject'] = "বিষয়";
$lang['eattendance_all_students'] = "সকল ছাত্রছাত্রী";
$lang['eattendance_select_exam'] = "নির্বাচন পরীক্ষা";
$lang['eattendance_select_classes'] = "নির্বাচন ক্লাস";
$lang['eattendance_select_subject'] = "নির্বাচন বিষয়";
$lang['action'] = "কর্ম";
$lang['add_attendance'] = "উপস্থিতি";
$lang['add_all_attendance'] = "সকল উপস্থিতি যোগ করুন";
$lang['view_attendance'] = "উপস্থিতি দেখুন";
