<?php

$lang['panel_title'] = "এসএমএস সেটিংস";
$lang['smssettings_username'] = "ইউজারনেম";
$lang['smssettings_password'] = "পাসওয়ার্ড";
$lang['smssettings_api_key'] = "Api Key";
$lang['smssettings_accountSID'] = "AccountSID";
$lang['smssettings_authtoken'] = "Auth Token";
$lang['smssettings_fromnumber'] = "From Number";
$lang['save'] = "সেভ";
