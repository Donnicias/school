<?php

$lang['panel_title'] = "বিষয়";
$lang['add_title'] = "একটি বিষয় যোগ করুন";
$lang['slno'] = "#";
$lang['subject_class_name'] = "ক্লাসের নাম";
$lang['subject_teacher_name'] = "শিক্ষকের নাম";
$lang['subject_student'] = "ছাত্র";
$lang['subject_name'] = "বিষয় নাম";
$lang['subject_author'] = "বিষয় লেখক";
$lang['subject_code'] = "বিষয় কোড";
$lang['subject_teacher'] = "শিক্ষক";
$lang['subject_classes'] = "ক্লাস";
$lang['subject_select_class'] = "নির্বাচন ক্লাস";
$lang['subject_select_classes'] = "নির্বাচন ক্লাস";
$lang['subject_select_teacher'] = "নির্বাচন শিক্ষক";
$lang['subject_select_student'] = "নির্বাচন ছাত্রছাত্রী";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_subject'] = "বিষয় যোগ করুন";
$lang['update_subject'] = "আপডেট বিষয়";
