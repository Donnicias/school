<?php

$lang['panel_title'] = "মেইল / এসএমএস টেমপ্লেট";
$lang['add_title'] = "একটি টেমপ্লেট যোগ করুন";
$lang['slno'] = "#";
$lang['mailandsmstemplate_name'] = "নাম";
$lang['mailandsmstemplate_user'] = "ইউজার";
$lang['mailandsmstemplate_tags'] = "ট্যাগ্স";
$lang['mailandsmstemplate_template'] = "টেমপ্লেট";
$lang['mailandsmstemplate_select_user'] = "নির্বাচন ইউজার";
$lang['mailandsmstemplate_student'] = "ছাত্রছাত্রী";
$lang['mailandsmstemplate_parents'] = "মাতাপিতা";
$lang['mailandsmstemplate_teacher'] = "শিক্ষক";
$lang['mailandsmstemplate_accountant'] = "হিসাবরক্ষক";
$lang['mailandsmstemplate_librarian'] = "গ্রন্থাগারিক";
$lang['mailandsmstemplate_type'] = "প্রকার";
$lang['mailandsmstemplate_select_type'] = "নির্বাচন করুন প্রকার";
$lang['mailandsmstemplate_email'] = "ইমেল";
$lang['mailandsmstemplate_sms'] = "এসএমএস";
$lang['mailandsmstemplate_select_tag'] = "নির্বাচন ট্যাগ";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_template'] = "টেমপ্লেট যোগ করুন";
$lang['update_template'] = "আপডেট টেমপ্লেট";
