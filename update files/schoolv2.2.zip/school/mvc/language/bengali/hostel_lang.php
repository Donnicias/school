<?php

$lang['panel_title'] = "হোস্টেল";
$lang['add_title'] = "একটি হোস্টেল যোগ করুন";
$lang['slno'] = "#";
$lang['hostel_name'] = "নাম";
$lang['hostel_htype'] = "প্রকার";
$lang['hostel_address'] = "ঠিকানা";
$lang['hostel_note'] = "বিঃদ্রঃ";
$lang['select_hostel_type'] = "নির্বাচন করুন প্রকার";
$lang['hostel_boys'] = "ছেলেদের";
$lang['hostel_girls'] = "মেয়েদের";
$lang['hostel_combine'] = "উভয়";
$lang['action'] = "কর্ম";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_hostel'] = "হোস্টেল যোগ";
$lang['update_hostel'] = "আপডেট হোস্টেল";
