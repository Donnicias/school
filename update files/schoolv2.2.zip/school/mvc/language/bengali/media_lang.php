<?php

$lang['panel_title'] = "মিডিয়া";
$lang['add_title'] = "ফোল্ডার তৈরি করুন";
$lang['slno'] = "#";
$lang['media_title'] = "শিরোনাম";
$lang['media_date'] = "তারিখ";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_class'] = "মিডিয়া যোগ করুন";
$lang['update_class'] = "আপডেট মিডিয়া";
$lang['file'] = "মিডিয়া";
$lang['upload_file'] = "মিডিয়া আপলোড করুন";
$lang['folder_name'] = "ফোল্ডারের নাম";
$lang['share'] = "শেয়ার";
$lang['share_with'] = "শেয়ার উইথ";
$lang['select_class'] = "নির্বাচন ক্লাস";
$lang['all_class'] = "সকল ক্লাস";
$lang['public'] = "পাবলিক";
$lang['class'] = "ক্লাস";
