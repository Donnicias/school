<?php

$lang['panel_title'] = "প্রোফাইল";
$lang['profile_roll'] = "রোল";
$lang['profile_email'] = "ইমেল";
$lang['profile_dob'] = "জন্ম তারিখ";
$lang['profile_jod'] = "যোগদান তারিখ";
$lang['profile_sex'] = "লিঙ্গ";
$lang['profile_religion'] = "ধর্ম";
$lang['profile_phone'] = "ফোন";
$lang['profile_address'] = "ঠিকানা";
$lang['profile_guargian_name'] = "অভিভাবক নাম";
$lang['profile_father_name'] = "পিতার নাম";
$lang['profile_mother_name'] = "মাতার নাম";
$lang['profile_father_profession'] = "পিতার পেশা";
$lang['profile_mother_profession'] = "মাতার পেশা";
$lang['parent_error'] = "মাতাপিতা এখনো যোগ করা হয়নি! অনুগ্রহপূর্বক মাতাপিতার তথ্য যোগ করুন.";
$lang['personal_information'] = "ব্যক্তিগত তথ্য";
$lang['parents_information'] = "মাতাপিতা তথ্য";
