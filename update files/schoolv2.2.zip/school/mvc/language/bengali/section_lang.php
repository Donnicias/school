<?php

$lang['panel_title'] = "শাখা";
$lang['add_title'] = "একটি শাখা যুক্ত করুন";
$lang['slno'] = "#";
$lang['section_name'] = "শাখা";
$lang['section_category'] = "বিভাগ";
$lang['section_classes'] = "ক্লাস";
$lang['section_teacher_name'] = "শিক্ষকের নাম";
$lang['section_note'] = "নোট";
$lang['action'] = "কর্ম";
$lang['section_select_class'] = "নির্বাচন ক্লাস";
$lang['section_select_teacher'] = "নির্বাচন শিক্ষক";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_class'] = "শাখা যোগ করুন";
$lang['update_class'] = "আপডেট শাখা";
