<?php

$lang['panel_title'] = "হিসাব";
$lang['slno'] = "#";
$lang['balance_classesID'] = "ক্লাস";
$lang['balance_select_classes'] = "নির্বাচন ক্লাস";
$lang['balance_all_students'] = "সকল ছাত্রছাত্রী";
$lang['balance_photo'] = "ছবি";
$lang['balance_name'] = "নাম";
$lang['balance_roll'] = "রোল";
$lang['balance_phone'] = "ফোন";
$lang['balance_totalbalance'] = "মোট হিসাব";
