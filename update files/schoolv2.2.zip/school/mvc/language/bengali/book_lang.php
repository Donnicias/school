<?php

$lang['panel_title'] = "বই";
$lang['add_title'] = "একটি বই যোগ করুন";
$lang['slno'] = "#";
$lang['book_name'] = "নাম";
$lang['book_subject_code'] = "বিষয় কোড";
$lang['book_author'] = "লেখক";
$lang['book_price'] = "মূল্য";
$lang['book_quantity'] = "পরিমাণ";
$lang['book_rack_no'] = "কোন রাক";
$lang['book_status'] = "অবস্থা";
$lang['book_available'] = "এখনো আছে";
$lang['book_unavailable'] = "নেই";
$lang['action'] = "কর্ম";
$lang['view'] = "দৃশ্য";
$lang['edit'] = "সম্পাদন করা";
$lang['delete'] = "মুছে দিন";
$lang['add_book'] = "বই যোগ করুন";
$lang['update_book'] = "বই আপডেট করুন";
