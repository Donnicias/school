<?php

$lang['panel_title'] = "প্রমোশন";
$lang['add_title'] = "প্রমোশন যোগ করুন";
$lang['slno'] = "#";
$lang['promotion_photo'] = "ছবি";
$lang['promotion_name'] = "নাম";
$lang['promotion_section'] = "শাখা";
$lang['promotion_result'] = "ফলাফল";
$lang['promotion_pass'] = "পাস";
$lang['promotion_fail'] = "ফেল";
$lang['promotion_modarate'] = "এখনো হয়নি";
$lang['promotion_phone'] = "ফোন";
$lang['promotion_classes'] = "ক্লাস";
$lang['promotion_roll'] = "রোল";
$lang['promotion_create_class'] = "একটি নতুন ক্লাস তৈরি করুন";
$lang['promotion_select_class'] = "নির্বাচন ক্লাস";
$lang['promotion_select_student'] = "নির্বাচন ছাত্রছাত্রী";
$lang['add_all_promotion'] = "সকল প্রমোশন";
$lang['promotion_alert'] = "সতর্ক";
$lang['promotion_ok'] = "ঠিক আছে";
$lang['promotion_success'] = "প্রোমোশন সাফল্য";
$lang['promotion_emstudent'] = "খালি ছাত্রছাত্রীর তালিকা";
$lang['action'] = "কর্ম";
$lang['add_mark_setting'] = "প্রোমোশন মার্ক সেটিং";
$lang['add_promotion'] = "পরবর্তী ক্লাসে প্রমোশন করুন";
