<?php

$lang['panel_title'] = "考试时间表";
$lang['add_title'] = "添加进度考试";
$lang['slno'] = "＃";
$lang['examschedule_name'] = "考试名称";
$lang['examschedule_classes'] = "类";
$lang['examschedule_all_examschedule'] = "所有考试时间表";
$lang['examschedule_select_exam'] = "选择考试";
$lang['examschedule_select_classes'] = "选择类别";
$lang['examschedule_select_subject'] = "选择主题";
$lang['examschedule_select_section'] = "选择部分";
$lang['examschedule_select_student'] = "选择学生";
$lang['examschedule_section'] = "部分";
$lang['examschedule_student'] = "学生";
$lang['examschedule_subject'] = "学科";
$lang['examschedule_date'] = "日期";
$lang['examschedule_time'] = "时间";
$lang['examschedule_examfrom'] = "时间从";
$lang['examschedule_examto'] = "时间";
$lang['examschedule_room'] = "房";
$lang['examschedule_note'] = "注意";
$lang['action'] = "行动";
$lang['view'] = "视图";
$lang['edit'] = "编辑";
$lang['delete'] = "删除";
$lang['add_examschedule'] = "添加考试时间表";
$lang['update_examschedule'] = "更新考试时间表";
