<?php

$lang['panel_title'] = "仪表盘";
$lang['dashboard_notice'] = "通知";
$lang['dashboard_username'] = "用户名";
$lang['dashboard_email'] = "电子邮件";
$lang['dashboard_phone'] = "电话";
$lang['dashboard_address'] = "地址";
$lang['dashboard_libraryfee'] = "库费";
$lang['dashboard_transportfee'] = "运输费";
$lang['dashboard_hostelfee'] = "宿费";
$lang['dashboard_earning_graph'] = "收益图";
$lang['dashboard_notpaid'] = "未支付";
$lang['dashboard_partially_paid'] = "部分支付";
$lang['dashboard_fully_paid'] = "缴足";
$lang['dashboard_cash'] = "现金";
$lang['dashboard_cheque'] = "支票";
$lang['dashboard_paypal'] = "支付宝";
$lang['dashboard_stripe'] = "条纹";
$lang['dashboard_sample'] = "样本";
$lang['view'] = "视图";
