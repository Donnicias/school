<?php

$lang['panel_title'] = "平衡";
$lang['slno'] = "＃";
$lang['balance_classesID'] = "类";
$lang['balance_select_classes'] = "选择类别";
$lang['balance_all_students'] = "所有学生";
$lang['balance_photo'] = "照片";
$lang['balance_name'] = "名字";
$lang['balance_roll'] = "滚";
$lang['balance_phone'] = "电话";
$lang['balance_totalbalance'] = "总余额";
