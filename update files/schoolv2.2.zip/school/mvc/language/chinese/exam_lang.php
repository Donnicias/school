<?php

$lang['panel_title'] = "考试";
$lang['add_title'] = "添加考试";
$lang['slno'] = "＃";
$lang['exam_name'] = "考试名称";
$lang['exam_date'] = "日期";
$lang['exam_note'] = "注意";
$lang['action'] = "行动";
$lang['view'] = "视图";
$lang['edit'] = "编辑";
$lang['delete'] = "删除";
$lang['add_exam'] = "添加考试";
$lang['update_exam'] = "更新考试";
