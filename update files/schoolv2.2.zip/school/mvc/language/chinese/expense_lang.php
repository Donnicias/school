<?php

$lang['panel_title'] = "费用";
$lang['add_title'] = "添加费用";
$lang['slno'] = "＃";
$lang['expense_expense'] = "名字";
$lang['expense_date'] = "日期";
$lang['expense_amount'] = "量";
$lang['expense_note'] = "注意";
$lang['expense_uname'] = "用户";
$lang['expense_total'] = "总";
$lang['action'] = "行动";
$lang['view'] = "视图";
$lang['edit'] = "编辑";
$lang['delete'] = "删除";
$lang['add_expense'] = "增加费用";
$lang['update_expense'] = "更新费用";
