<?php

$lang['panel_title'] = "类别";
$lang['add_title'] = "添加类别";
$lang['slno'] = "＃";
$lang['category_hname'] = "旅馆名称";
$lang['category_class_type'] = "类的类型";
$lang['category_hbalance'] = "宿费";
$lang['category_note'] = "注意";
$lang['category_select_hostel'] = "选择旅馆";
$lang['action'] = "行动";
$lang['edit'] = "编辑";
$lang['delete'] = "删除";
$lang['add_category'] = "添加类别";
$lang['update_category'] = "Update分类";
