<?php

$lang['panel_title'] = "费用类型";
$lang['add_title'] = "添加费用类型";
$lang['slno'] = "＃";
$lang['feetype_name'] = "费用类型";
$lang['feetype_note'] = "注意";
$lang['action'] = "行动";
$lang['edit'] = "编辑";
$lang['delete'] = "删除";
$lang['add_feetype'] = "添加费用类型";
$lang['update_feetype'] = "更新费类型";
