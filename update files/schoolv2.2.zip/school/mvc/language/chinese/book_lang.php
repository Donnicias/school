<?php

$lang['panel_title'] = "书籍";
$lang['add_title'] = "添加一本书";
$lang['slno'] = "＃";
$lang['book_name'] = "名字";
$lang['book_subject_code'] = "科目代码";
$lang['book_author'] = "笔者";
$lang['book_price'] = "价格";
$lang['book_quantity'] = "数量";
$lang['book_rack_no'] = "机架号";
$lang['book_status'] = "状态";
$lang['book_available'] = "可用的";
$lang['book_unavailable'] = "不可用";
$lang['action'] = "行动";
$lang['view'] = "视图";
$lang['edit'] = "编辑";
$lang['delete'] = "删除";
$lang['add_book'] = "加入书";
$lang['update_book'] = "更新图书";
