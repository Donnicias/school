<?php

$lang['panel_title'] = "类";
$lang['add_title'] = "添加类";
$lang['slno'] = "＃";
$lang['classes_name'] = "类";
$lang['classes_numeric'] = "数字类";
$lang['teacher_name'] = "老师的名字";
$lang['classes_note'] = "注意";
$lang['action'] = "行动";
$lang['classes_select_teacher'] = "选择教师";
$lang['view'] = "视图";
$lang['edit'] = "编辑";
$lang['delete'] = "删除";
$lang['add_class'] = "添加类";
$lang['update_class'] = "更新讲习";
