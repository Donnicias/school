<?php

$lang['panel_title'] = "考试出席";
$lang['add_title'] = "添加考勤考试";
$lang['slno'] = "＃";
$lang['eattendance_photo'] = "照片";
$lang['eattendance_name'] = "名字";
$lang['eattendance_email'] = "电子邮件";
$lang['eattendance_roll'] = "滚";
$lang['eattendance_phone'] = "电话";
$lang['eattendance_attendance'] = "勤";
$lang['eattendance_section'] = "部分";
$lang['eattendance_exam'] = "考试";
$lang['eattendance_classes'] = "类";
$lang['eattendance_subject'] = "学科";
$lang['eattendance_all_students'] = "所有学生";
$lang['eattendance_select_exam'] = "选择考试";
$lang['eattendance_select_classes'] = "选择类别";
$lang['eattendance_select_subject'] = "选择主题";
$lang['action'] = "行动";
$lang['add_attendance'] = "勤";
$lang['add_all_attendance'] = "加入所有的考勤";
$lang['view_attendance'] = "查看考勤";
